﻿using System;
using System.Web;
using System.Web.UI;
using Yenetch.Crm;

namespace Yenetch.Web.Admin
{
    /// <summary>Layout for the admin area: sidebar with role-aware navigation, counts that need attention, and flash messages.</summary>
    public partial class AdminMaster : MasterPage
    {
        protected CrmUser Me { get { return Auth.Current; } }
        protected string FlashMessage { get; private set; }
        protected int NewLeads { get; private set; }
        protected int Overdue { get; private set; }
        protected int NewApplications { get; private set; }
        protected int TodayCalls { get; private set; }
        public string RefreshAttr { get; set; }

        public const string LogoSvg = "<svg viewBox=\"0 0 100 100\" aria-hidden=\"true\"><path fill=\"#0A0A0B\" d=\"M5.49,32.32C5.55,31.58 5.48,30.70 5.62,30.00C6.54,25.28 9.61,21.65 13.78,19.42C14.31,19.13 14.88,18.83 15.40,18.53L23.87,13.63L37.33,5.86C41.90,3.23 45.59,0.34 51.23,0.94C55.62,1.40 57.99,3.23 61.70,5.37L71.80,11.21L82.80,17.55C84.31,18.43 86.49,19.58 87.88,20.51C89.02,21.27 90.05,22.19 90.94,23.23C92.63,25.25 93.78,27.67 94.28,30.26C94.68,32.39 94.54,35.73 94.54,38.02L94.54,49.54L94.54,61.92C94.54,63.89 94.62,66.55 94.49,68.43C94.24,72.16 92.13,76.26 89.21,78.61C87.62,79.90 85.47,81.03 83.65,82.07L76.78,86.00L74.03,87.61C73.42,87.97 72.84,88.46 72.17,88.64C71.77,88.75 71.56,89.01 71.20,89.23L68.67,90.73L63.44,93.79C63.15,93.96 62.79,94.03 62.44,94.24C58.94,96.29 54.84,99.48 50.61,99.03C49.82,99.03 49.08,99.03 48.30,99.09C45.52,99.02 42.98,97.63 40.69,96.21C39.97,95.77 39.07,95.42 38.42,94.87C37.98,94.79 32.68,91.60 32.01,91.21C28.89,89.38 25.75,87.58 22.59,85.80C20.22,84.49 17.90,83.02 15.53,81.70C13.19,80.40 10.77,79.12 9.03,77.04C8.65,76.60 8.08,75.91 7.82,75.41C7.54,74.87 7.16,74.35 6.88,73.82C6.29,72.68 5.78,71.21 5.59,69.94C5.40,68.71 5.49,67.17 5.49,65.90L5.49,58.96L5.49,32.32zM54.81,10.36C54.03,9.97 53.03,9.31 52.25,9.05C49.90,8.28 47.22,8.76 45.22,10.20C44.84,10.43 44.47,10.71 44.09,10.92C43.90,11.02 43.34,11.03 43.23,11.16C42.35,12.13 41.26,12.25 40.18,12.89C39.81,13.11 39.80,13.36 39.48,13.61C38.13,14.05 37.03,15.08 35.76,15.72C35.35,15.93 34.85,15.90 34.47,16.20C32.38,17.59 30.34,19.06 28.00,20.05C27.39,20.30 26.84,20.63 26.26,20.94C25.58,21.25 25.25,21.78 24.65,22.14C23.73,22.68 22.79,23.19 21.83,23.67C21.33,23.92 20.78,24.16 20.31,24.45C19.97,24.67 19.71,25.00 19.37,25.23C19.04,25.45 18.61,25.59 18.25,25.77C17.76,26.01 16.19,26.89 15.84,27.21C14.29,28.65 13.69,29.76 13.18,31.81C12.87,33.07 13.04,37.23 13.04,38.77L13.04,53.90L13.04,63.40C13.04,64.76 13.02,66.39 13.05,67.73C13.08,68.84 14.12,71.00 14.69,71.93C14.87,72.23 16.06,72.98 16.45,73.21C18.86,74.65 21.31,76.07 23.75,77.46L32.30,82.40L41.37,87.63C43.13,88.64 44.89,89.66 46.65,90.68C47.19,90.99 48.24,91.27 48.85,91.40C51.69,91.99 54.33,90.03 56.67,88.68L64.57,84.11L75.85,77.60L80.66,74.82C82.28,73.89 83.83,73.18 85.10,71.76C86.75,69.23 86.69,68.72 86.70,65.77L86.69,61.80L86.69,48.38L86.70,36.88C86.70,34.05 87.15,31.04 85.34,28.68C84.20,27.19 82.55,26.41 80.97,25.50C79.74,24.78 78.51,24.08 77.28,23.38L61.04,13.99L56.91,11.61C56.27,11.24 55.37,10.80 54.81,10.36z\"/><path fill=\"#0066FF\" d=\"M49.07,11.99C51.71,11.71 52.76,12.76 54.91,14.01L61.12,17.62L74.46,25.34C76.49,26.52 78.85,27.80 80.82,29.02L80.80,29.12C80.32,29.64 74.21,33.09 73.09,33.74L50.44,46.93L49.86,47.23L26.28,33.63L20.79,30.46C20.46,30.27 19.07,29.51 18.88,29.33L18.92,29.22C19.46,28.65 22.26,27.13 23.12,26.63L30.42,22.42L42.73,15.31C44.45,14.32 47.24,12.42 49.07,11.99z\"/><path fill=\"#0A0A0B\" d=\"M16.33,33.28L38.10,45.86L44.19,49.39C44.92,49.80 46.89,50.88 47.50,51.35L47.48,75.47L47.49,82.77C47.49,84.11 47.56,85.91 47.43,87.19C45.65,86.28 43.90,85.22 42.16,84.26C41.42,83.86 40.65,83.38 39.90,83.02C39.80,82.29 39.83,81.10 39.84,80.33L39.84,76.09L39.84,62.65C39.84,60.55 39.94,57.59 39.81,55.61C39.20,55.36 37.77,54.51 37.13,54.15L32.21,51.35C30.60,50.43 16.40,42.46 16.15,42.13C16.21,40.16 16.11,38.15 16.15,36.17C16.16,35.64 16.06,33.58 16.33,33.28z\"/><path fill=\"#0A0A0B\" d=\"M83.01,33.44C83.19,33.42 83.29,33.39 83.43,33.49C83.53,34.35 83.49,36.04 83.49,36.96C83.48,38.66 83.52,40.48 83.46,42.17C83.03,42.51 82.07,43.02 81.55,43.32L78.19,45.21L65.87,52.22L62.09,54.36C61.40,54.75 60.43,55.26 59.80,55.72C59.67,57.67 59.77,60.53 59.77,62.56L59.77,75.79C59.77,78.06 59.84,80.84 59.74,83.07C59.06,83.30 57.57,84.19 56.87,84.59L52.62,86.98C52.45,87.01 52.54,87.01 52.36,86.98C52.19,86.63 52.28,81.57 52.28,80.72L52.28,67.21L52.27,57.15C52.27,55.29 52.23,53.17 52.30,51.32C52.86,50.89 54.31,50.10 55.00,49.71L60.25,46.69L76.96,37.00L80.90,34.74C81.37,34.47 82.67,33.77 83.01,33.44z\"/></svg>";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Page.Title)) Page.Title = "Yenetch Admin";
            else if (!Page.Title.EndsWith("Yenetch Admin")) Page.Title += " · Yenetch Admin";

            var flash = Request.Cookies["yn_flash"];
            if (flash != null && !string.IsNullOrEmpty(flash.Value))
            {
                FlashMessage = HttpUtility.UrlDecode(flash.Value);
                Response.Cookies.Add(new HttpCookie("yn_flash", "") { Path = "/admin", Expires = DateTime.UtcNow.AddDays(-1) });
            }
            if (Request.QueryString["denied"] == "1") FlashMessage = "That page needs a different role. Ask an admin for access.";

            if (Me == null) return;
            NewLeads = Db.Scalar<int>("SELECT COUNT(*) FROM CrmLeads WHERE Status = 'New'" + (Me.SeesAllLeads ? "" : " AND (AssignedTo = @me OR AssignedTo IS NULL)"), new { me = Me.Id });
            if (Me.CanUseMarketing) NewApplications = Db.Scalar<int>("SELECT COUNT(*) FROM CrmApplications WHERE Status = 'New'");
            TodayCalls = Db.Scalar<int>("SELECT COUNT(*) FROM Bookings WHERE Status = 'Confirmed' AND StartOn >= @now AND StartOn < @end", new { now = DateTime.UtcNow, end = Util.FromIst(Util.TodayIst.AddDays(1)) });
            Overdue = LeadService.FollowUps(Me.SeesAllLeads ? (int?)null : Me.Id, DateTime.UtcNow, 100).Count;
        }

        protected string Section { get { var p = Page as AdminPage; return p == null ? "" : p.Section; } }

        protected string Link(string key, string href, string icon, string text, int count)
        {
            var on = Section == key;
            return "<a href=\"" + href + "\"" + (on ? " class=\"is-on\" aria-current=\"page\"" : "") + ">" + AdminPage.Icon(icon) + HttpUtility.HtmlEncode(text)
                 + (count > 0 ? "<span class=\"count\">" + (count > 99 ? "99+" : count.ToString()) + "</span>" : "") + "</a>";
        }

        protected static string Icon(string name) { return AdminPage.Icon(name); }
    }
}
